import time
import sys
import os
import socket
import hmac
from struct import pack, unpack_from
import json
import base64

DEFAULT_NAME = '.dstu-agent.sock'
TYPES = {
    0x04: 'octstr',
    0x13: 'printstr',
    'printstr': 0x13,
    'octstr': 0x04
}


class OperationError(Exception):
    def __init__(self, code):
        self.code = code


class ProtocolError(Exception):
    pass


def encode_len(type_name, byte_len):
    type_code = TYPES[type_name]
    if byte_len < 0x80:
        return pack('BB', type_code, byte_len)
    if byte_len < 0x100:
        return pack('BBB', type_code, 0x81, byte_len)

    if byte_len < 0x10000:
        return pack('BBBB', type_code, 0x82, byte_len >> 8, byte_len & 0xFF)

    if byte_len < 0x1000000:
        return pack('BBBBB', type_code, 0x83, byte_len >> 16, (byte_len >> 8) & 0xFF, byte_len & 0xFF)

    raise ProtocolError('Length is too big {}'.format(byte_len))


def read_header(read):
    (typ_code, byte_len) = unpack_from('BB', read(2))
    if (byte_len & 0x80) > 0:
        oct_len = byte_len ^ 0x80
        byte_len = 0
        off = 2
        while oct_len > 0:
            byte_len = byte_len << 8
            (len_byte,) = unpack_from('B', read(1))
            oct_len = oct_len - 1
            byte_len = byte_len | len_byte

    return (TYPES.get(typ_code), byte_len)


CONTROL_LEN = 32


class Connection:
    def __init__(self, socket, key):
        self.socket = socket
        self.key = key
        self.ohmac = hmac.new(key, digestmod='sha256')
        self.ihmac = hmac.new(key, digestmod='sha256')

    def reset_ohmac(self):
        digest = self.ohmac.digest()
        self.ohmac = hmac.new(self.key, digestmod='sha256')
        self.ohmac.update(digest)
        return digest

    def reset_ihmac(self):
        digest = self.ihmac.digest()
        self.ihmac = hmac.new(self.key, digestmod='sha256')
        self.ihmac.update(digest)
        return digest

    def command(self, type_name, buf):
        header = encode_len(type_name, len(buf))
        self.ohmac.update(header)
        self.ohmac.update(buf)
        self.socket.send(header)
        self.socket.send(buf)
        self.socket.send(self.reset_ohmac())

    def read_type(self):
        def read(count):
            ret = b''
            while count > 0:
                part = self.socket.recv(count)
                self.ihmac.update(part)
                count -= len(part)
                ret += part
            return ret

        (type_name, byte_len) = read_header(read)
        data = read(byte_len)
        # control = self.socket.recv(CONTROL_LEN)
        control = b''
        while len(control) < CONTROL_LEN:
            control += self.socket.recv(CONTROL_LEN - len(control))

        dgst = self.reset_ihmac()
        if not hmac.compare_digest(control, dgst):
            raise ProtocolError('HMAC')

        return (type_name, data)


def command_json(cn, data):
    return cn.command('printstr', json.dumps(data).encode('utf8'))


def send_content(cn, data):
    return cn.command('octstr', data)


def read_json(cn, expect_op):
    type_name, response_body = cn.read_type()
    # print(type_name, response_body)
    if type_name != 'printstr':
        raise ProtocolError('Unexpected data response, expect json')
    data = json.loads(response_body.decode('utf8'))
    if data['op'] == 'ERROR':
        raise OperationError(data['code'])
    if data['op'] != expect_op:
        raise ProtocolError('Unexpected response op', data['op'])

    return data


def read_data(cn):
    type_name, response_body = cn.read_type()
    if type_name == 'printstr':
        data = json.loads(response_body.decode('utf8'))
        if data['op'] == 'ERROR':
            raise OperationError(data['code'])
        else:
            raise ProtocolError('Unexpected json response, expected data', data['op'])

    return response_body


def info(cn, bid):
    command_json(cn, {'op': 'INFO', 'bid': bid})
    certs = read_json(cn, 'CERTS')
    read_json(cn, 'READY')
    return certs['certs']


def pipe(cn, bid, content, pipe):
    send_content(cn, content)
    command_json(cn, {"op": "PIPE", "pipe": pipe, 'bid': bid})
    response = read_data(cn)
    read_json(cn, 'RPIPE')
    return response


def unwrap(cn, bid, content, ocsp=None, tsp=None):
    send_content(cn, content)
    command_json(cn, {"op": "UNWRAP", 'bid': bid, 'opts': {'ocsp': ocsp, 'tsp': tsp}})
    response = read_data(cn)
    meta = read_json(cn, 'META')
    return (response, meta)


def init_box(cn):
    command_json(cn, {"op": "INIT"})
    return read_json(cn, 'CREATED')['bid']


def evict_box(cn, bid):
    command_json(cn, {"op": "EVICT", 'bid': bid})
    return read_json(cn, 'GONE')


def add_key(cn, bid, contents, password=None):
    send_content(cn, contents)
    command_json(cn, {"op": "ADD_KEY", 'password': password, 'bid': bid})
    read_json(cn, 'DONE')


def add_cert(cn, bid, contents):
    send_content(cn, contents)
    command_json(cn, {"op": "ADD_CERT", 'bid': bid})
    read_json(cn, 'DONE')


def unpack_key(cn, contents, password):
    send_content(cn, contents)
    command_json(cn, {"op": "UNPROTECT", 'password': password})
    ret = read_json(cn, 'CLEAR')
    return ret['keys']


def read_key1(path, password):
    with open(path, 'rb') as key_file:
        return {'password': password, 'contents': key_file.read()}


def read_certs(certpath1, certpath2):
    with open(certpath1, 'rb') as cert_file:
        cert1 = cert_file.read()

    with open(certpath2, 'rb') as cert_file:
        cert2 = cert_file.read()

    return [cert1, cert2]


def connect(mode='unix', path='', key=None):
    if mode == 'unix':
        home = os.getenv('HOME', '/tmp/')
        default_path = os.path.join(home, DEFAULT_NAME)
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM);
        s.connect(path or default_path)
    elif mode == 'ip6':
        s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
        (host, port) = path.rsplit(':') if (':' in path and not path.startswith('[')) else (None, path)
        s.connect((host or '::', int(port) if port else 3111))
    elif mode == 'ip4':
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        (host, port) = path.rsplit(':') if (':' in path) else (None, path)
        s.connect((host or '127.0.0.1', int(port) if port else 3111))

    else:
        return sys.exit(1)

    cn = Connection(s, bytes.fromhex(key) if key else (b'\x00' * 32))

    # bid1 = 'ca06e915fb7f4f85effe60cbe4114f6b0f9870d8ea5e6b61f6f667d57a43723e'
    # data_test = b'{"Command": "ServerState"}'
    #
    # sdata = pipe(cn, bid1, data_test, [{"op": "sign", "role": "stamp"}])
    # # print('w', sdata)
    # (rdata, meta) = unwrap(cn, bid1, sdata, ocsp=None)
    # print('r', repr(rdata))
    # print(meta)

    key_path = './test-keys/1/Key-6.dat'
    password = '1314'
    keys = unpack_key(cn, **read_key1(key_path, password))
    # print(keys)
    bid1 = init_box(cn)
    print(bid1)

    # exit()
    for key in keys:
        add_key(cn, bid1, key['contents'].encode('latin1'))
        break

    certpath1 = './test-keys/1/CertificateSN8840012.cer'
    certpath2 = './test-keys/1/CertificateSN8840013.cer'

    for cert in read_certs(certpath1, certpath2):
        add_cert(cn, bid1, cert)
        break

    data_test = b'<?xml version=\'1.0\' encoding=\'windows-1251\'?>\n<ZREP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="check01.xsd">\n  <ZREPHEAD>\n    <UID>8bd266f2-28ba-11eb-8e51-0123be5354a8</UID>\n    <TIN></TIN>\n    <ORGNM></ORGNM>\n    <POINTNM></POINTNM>\n    <POINTADDR></POINTADDR>\n    <ORDERDATE>17112020</ORDERDATE>\n    <ORDERTIME>115203</ORDERTIME>\n    <ORDERNUM>385</ORDERNUM>\n    <CASHDESKNUM></CASHDESKNUM>\n    <CASHREGISTERNUM>4000042829</CASHREGISTERNUM>\n    <VER>1</VER>\n    <ORDERTAXNUM>1</ORDERTAXNUM>\n  </ZREPHEAD>\n  <ZREPVAL>\n    <TOTALINADVANCE>0.00</TOTALINADVANCE>\n    <TOTALINATTACH>0.00</TOTALINATTACH>\n    <TOTALSURRCOLLECTION>0.00</TOTALSURRCOLLECTION>\n    <COMMISSION>0.00</COMMISSION>\n    <CALCDOCSCNT>12</CALCDOCSCNT>\n    <ACCEPTEDN>0.00</ACCEPTEDN>\n    <ISSUEDN>0.00</ISSUEDN>\n    <COMMISSIONN>0.00</COMMISSIONN>\n    <TRANSFERSCNT>0</TRANSFERSCNT>\n    <DETAILS>\n      <ROW ROWNUM="1"><VALCD>840</VALCD><VALSYMCD>USD</VALSYMCD><BUYVALI>6.00</BUYVALI><SELLVALI>0.00</SELLVALI><BUYVALN>0.00</BUYVALN><SELLVALN>163.20</SELLVALN><STORBUYVALI>6.00</STORBUYVALI><STORSELLVALI>0.00</STORSELLVALI><STORBUYVALN>0.00</STORBUYVALN><STORSELLVALN>163.20</STORSELLVALN><CINVALI>0.00</CINVALI><COUTVALI>0.00</COUTVALI><COMMISSION>0.00</COMMISSION><INADVANCE>0.00</INADVANCE><INATTACH>0.00</INATTACH><SURRCOLLECTION>0.00</SURRCOLLECTION><STORCINVALI>0.00</STORCINVALI><STORCOUTVALI>0.00</STORCOUTVALI><STORCOMMISSION>0.00</STORCOMMISSION></ROW>\n    </DETAILS>\n  </ZREPVAL>\n  <ZREPBODY>\n    <SERVICEINPUT>0.00</SERVICEINPUT>\n    <SERVICEOUTPUT>0.00</SERVICEOUTPUT>\n  </ZREPBODY>\n</ZREP>\n'

    # sdata = pipe(cn, bid1, data_test, [{"op": "sign", "role": "stamp", "tsp": "signature", "tax": True}])
    # print('w', sdata)

    key247221_pem = '247221.pem'
    with open(key247221_pem, "rb") as file:
        cert = file.read()
        cert = base64.b64encode(cert).decode()

    sdata = pipe(cn, bid1, data_test, [{"op": "sign", "role": "stamp", "tax": True},
                                                    {"op": "encrypt", "role": "stamp", "forCert": cert, "tax": True},
                                                    {"op": "sign", "role": "stamp", "tax": True}])
    print('w', sdata)

    # # f = open("sdata.txt", "wb")
    # # f.write(sdata)
    # # f.close()
    #
    # (rdata, meta) = unwrap(cn, bid1, sdata, ocsp=None, tsp='signature') #, tsp='signature'
    # print('r', repr(rdata))
    # print(meta)
    #
    # exit()
    #
    # bid1 = 'fa2fd58177f686c36d87a26ff2ce91e33cc721d8e8ddcab74076c912ed5b1674'
    # data_test = b'<?xml version=\'1.0\' encoding=\'windows-1251\'?>\n<ZREP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="check01.xsd">\n  <ZREPHEAD>\n    <UID>8bd266f2-28ba-11eb-8e51-0123be5354a8</UID>\n    <TIN></TIN>\n    <ORGNM></ORGNM>\n    <POINTNM></POINTNM>\n    <POINTADDR></POINTADDR>\n    <ORDERDATE>17112020</ORDERDATE>\n    <ORDERTIME>115203</ORDERTIME>\n    <ORDERNUM>385</ORDERNUM>\n    <CASHDESKNUM></CASHDESKNUM>\n    <CASHREGISTERNUM>4000042829</CASHREGISTERNUM>\n    <VER>1</VER>\n    <ORDERTAXNUM>1</ORDERTAXNUM>\n  </ZREPHEAD>\n  <ZREPVAL>\n    <TOTALINADVANCE>0.00</TOTALINADVANCE>\n    <TOTALINATTACH>0.00</TOTALINATTACH>\n    <TOTALSURRCOLLECTION>0.00</TOTALSURRCOLLECTION>\n    <COMMISSION>0.00</COMMISSION>\n    <CALCDOCSCNT>12</CALCDOCSCNT>\n    <ACCEPTEDN>0.00</ACCEPTEDN>\n    <ISSUEDN>0.00</ISSUEDN>\n    <COMMISSIONN>0.00</COMMISSIONN>\n    <TRANSFERSCNT>0</TRANSFERSCNT>\n    <DETAILS>\n      <ROW ROWNUM="1"><VALCD>840</VALCD><VALSYMCD>USD</VALSYMCD><BUYVALI>6.00</BUYVALI><SELLVALI>0.00</SELLVALI><BUYVALN>0.00</BUYVALN><SELLVALN>163.20</SELLVALN><STORBUYVALI>6.00</STORBUYVALI><STORSELLVALI>0.00</STORSELLVALI><STORBUYVALN>0.00</STORBUYVALN><STORSELLVALN>163.20</STORSELLVALN><CINVALI>0.00</CINVALI><COUTVALI>0.00</COUTVALI><COMMISSION>0.00</COMMISSION><INADVANCE>0.00</INADVANCE><INATTACH>0.00</INATTACH><SURRCOLLECTION>0.00</SURRCOLLECTION><STORCINVALI>0.00</STORCINVALI><STORCOUTVALI>0.00</STORCOUTVALI><STORCOMMISSION>0.00</STORCOMMISSION></ROW>\n    </DETAILS>\n  </ZREPVAL>\n  <ZREPBODY>\n    <SERVICEINPUT>0.00</SERVICEINPUT>\n    <SERVICEOUTPUT>0.00</SERVICEOUTPUT>\n  </ZREPBODY>\n</ZREP>\n'
    #
    # sdata = pipe(cn, bid1, data_test, [{"op": "sign", "role": "stamp", "tsp": "signature"}])
    # # print('w', sdata)
    # (rdata, meta) = unwrap(cn, bid1, sdata, ocsp=None)
    # print('r', repr(rdata))
    # print(meta)


    # #key2
    # key_path = './test-keys/2/Key-6.dat'
    # password = '39307260'
    # keys = unpack_key(cn, **read_key1(key_path, password))
    # # print(keys)
    # bid2 = init_box(cn)
    # print(bid2)
    #
    # # exit()
    # for key in keys:
    #     add_key(cn, bid2, key['contents'].encode('latin1'))
    #     break
    #
    # certpath1 = './test-keys/2/CertificateSN9099832.cer'
    # certpath2 = './test-keys/2/CertificateSN9099833.cer'
    #
    # for cert in read_certs(certpath1, certpath2):
    #     add_cert(cn, bid2, cert)
    #     break
    #
    # #key3
    # key_path = './test-keys/3/Key-6.dat'
    # password = 'tect4'
    # keys = unpack_key(cn, **read_key1(key_path, password))
    # # print(keys)
    # bid3 = init_box(cn)
    # # print(bid3)

    # exit()
    # for key in keys:
    #     add_key(cn, bid3, key['contents'].encode('latin1'))# с базы послать
    #     break
    #
    # certpath1 = './test-keys/3/Тестовий_платник_4_(Тест)-8101905.cer'
    # certpath2 = './test-keys/3/Тестовий_платник_4_(Тест)-8101906.cer'
    #
    # for cert in read_certs(certpath1, certpath2):
    #     add_cert(cn, bid3, cert)
    #     break

    # evict_box(cn, bid1)
    #
    # s_time = time.time()
    # for x in range(1):
    #     # time.sleep(20)
    #
    #     # for cert in info(cn, bid):
    #     #  print('c', cert)
    #
    #     data_test = 'HELLO {}'.format(x)
    #
    #     sdata = pipe(cn, bid1, data_test.encode('utf8'), [{"op": "sign", "role": "stamp"}])
    #     # print('w', sdata)
    #     (rdata, meta) = unwrap(cn, bid1, sdata, ocsp=None)
    #     print('r', repr(rdata))
    #     print(meta)
    #
    #
    #     # i = info(cn, bid1)
    #     # print(i)
    #     #
    #     # sdata = pipe(cn, bid2, data_test2.encode('utf8'), [{"op": "sign", "role": "stamp"}])
    #     # # print('w', sdata)
    #     # (rdata, meta) = unwrap(cn, bid2, sdata, ocsp=None)
    #     # print('r',repr(rdata))
    #     # i = info(cn, bid2)
    #     # print(i)
    #
    #     # sdata = pipe(cn, bid3, data_test3.encode('utf8'), [{"op": "sign"}])
    #     # # print('w', sdata)
    #     # (rdata, meta) = unwrap(cn, bid3, sdata, ocsp=None)
    #     # print('r',repr(rdata.decode()))
    #     # # i = info(cn, bid3)
    #     # # print(i)
    #     #
    #     # print(meta)
    #     # info(cn, bid)
    #     # evict_box(cn, bid1)
    #
    #     # if rdata.decode('utf8') != data_test:
    #     #  print('boooo')
    #     #  break
    #
    # total_time = time.time() - s_time
    # print('time', total_time, (x*9 + 1) / total_time)


if __name__ == '__main__':
    frame = connect(*sys.argv[1:])
